import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class MazeBuilder extends Application {
    private Button[][] maze;
    private int numRows, numCols;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Prompt user for dimensions
        String inputRows = JOptionPane.showInputDialog("Enter the number of rows:");
        String inputCols = JOptionPane.showInputDialog("Enter the number of columns:");
        numRows = Integer.parseInt(inputRows);
        numCols = Integer.parseInt(inputCols);

        maze = new Button[numRows][numCols];
        BorderPane root = new BorderPane();

        // Create GridPane and populate with buttons
        GridPane gridPane = new GridPane();
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                Button btn = new Button();
                btn.setStyle("-fx-background-color: blue;");
                btn.setPrefSize(30, 30);  // Set button size
                int finalRow = row;
                int finalCol = col;

                // Toggle button color on click
                btn.setOnAction(e -> toggleButton(btn));
                gridPane.add(btn, col, row);
                maze[row][col] = btn;
            }
        }

        root.setCenter(gridPane);

        // Create control panel
        HBox controlPanel = new HBox();
        Button saveButton = new Button("Save");
        saveButton.setOnAction(e -> saveMaze());
        Button exitButton = new Button("Exit");
        exitButton.setOnAction(e -> exitApp());

        controlPanel.getChildren().addAll(saveButton, exitButton);
        root.setBottom(controlPanel);

        Scene scene = new Scene(root, 800, 800);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Maze Builder");
        primaryStage.show();
    }

    private void toggleButton(Button btn) {
        String color = btn.getStyle();
        if (color.contains("blue")) {
            btn.setStyle("-fx-background-color: white;");  // Path
        } else if (color.contains("white")) {
            btn.setStyle("-fx-background-color: green;");  // Entry
        } else if (color.contains("green")) {
            btn.setStyle("-fx-background-color: red;");    // Exit
        } else {
            btn.setStyle("-fx-background-color: blue;");   // Wall
        }
    }

    private void saveMaze() {
        try (BufferedWriter writer = new BufferedWriter(new
                FileWriter("maze.txt"))) {
            writer.write(numRows + " " + numCols + "\n");
            for (int row = 0; row < numRows; row++) {
                for (int col = 0; col < numCols; col++) {
                    String color = maze[row][col].getStyle();
                    if (color.contains("blue")) writer.write("0");
                    else if (color.contains("white")) writer.write("1");
                    else if (color.contains("green")) writer.write("S");
                    else if (color.contains("red")) writer.write("E");
                }
                writer.newLine();
            }
        } catch (IOException ex) {
            Alert alert = new Alert(AlertType.ERROR, "Error saving maze: " + ex.getMessage());
            alert.showAndWait();
        }
    }

    private void exitApp() {
        int confirm = JOptionPane.showConfirmDialog(null, "Do you want to save before exiting?");
        if (confirm == JOptionPane.YES_OPTION) {
            saveMaze();
        }
        System.exit(0);
    }
}
